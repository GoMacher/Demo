package Barcode_Demo_pck;

public class Strichcode {

	private String str_CodeName;
	private String str_CodeWert;
	
	//Konstruktor
	public Strichcode (String strName, String strValue) {
		str_CodeName = strName;
		str_CodeWert = strValue;
	}
	
	//Getter- und Setterfunktionen
	public String getName() {
		return str_CodeName;
	}
	
	public void setName(String strName) {
		str_CodeName = strName;
	}
	
	public String getWert() {
		return str_CodeWert;
	}
	
	public void setWert (String strValue) {
		str_CodeWert = strValue;
	}
	
	public void setObjekt(String strName, String strValue) {
		str_CodeName = strName;
		str_CodeWert = strValue;
	}
	
	
	
}
