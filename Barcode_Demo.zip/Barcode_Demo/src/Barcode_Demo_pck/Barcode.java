package Barcode_Demo_pck;

public class Barcode {

	private String str_BarcodeWert;
	private Strichcode obj_Strichcode = new Strichcode ("-", "-");
	
	//Konstruktor
	public Barcode (String strWert, String strCode, String strCodeValue) {
		str_BarcodeWert = strWert;
		obj_Strichcode.setObjekt(strCode, strCodeValue);
	}
	
	//Getter- und Settermethoden
	public String getBarcodewert() {
		return str_BarcodeWert;
	}
	
	public String getCodeFormat() {
		return obj_Strichcode.getName();
	}
	
	public String getCodeMuster(){
		return obj_Strichcode.getWert();
	}
	
	public void setCodeWert (String strValue) {
		obj_Strichcode.setName(strValue);
	}
	
	public void setCodeFormat (String strFormat) {
		obj_Strichcode.setName(strFormat);
	}
	
	public void setCodeMuster (String strMuster) {
		obj_Strichcode.setWert(strMuster);
	}

}
