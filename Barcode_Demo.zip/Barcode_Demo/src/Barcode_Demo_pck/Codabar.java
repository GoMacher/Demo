package Barcode_Demo_pck;

public class Codabar {
	
	public boolean Eingabe_OK (String strInput) {
		/*
		 * Eingabe_OK prueft ob der in strInput uebergebene
		 * String nur Zahlen enthaelt 
		 */
		
		//Deklarationen 
		boolean b_Ret;
		int		i, i_Len;
		char 	chr_Zeichen;
		
		//Rueckgabewert initialisieren
		b_Ret = true;
		//Laenge der Zeichenketter ermitteln
		i_Len = strInput.length();
		//Zeichenkette pruefen
		for (i=0; i<i_Len; i++) {
			chr_Zeichen = strInput.charAt(i);
			switch (chr_Zeichen) {
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					break;
				default:
					return false;
			}
		}
		return b_Ret;
	}
	
	public String Strichcode_binaer (String strInput) {
		
		/*
		 * Strichcode_binaer wandelt den nach strInput uebergebenen String 
		 * in ein binaeres Strichcodemuster um. Dabei werden die einzelnen 
		 * Zeichen durch ein (interchar space encoded = 0) getrennt.
		 * Die Rueckgabe ist ein binaeres Strichcodemuster als String.
		 */
		
		//Deklarationen
		String	str_CodeMuster = "";
		String 	str_chrMuster = "";
		int 	i=0, i_Len;
		char 	chr_Zeichen;
		
		//Laenge der Zeichenketter ermitteln
		i_Len = strInput.length();
		//Zeichenkette durchlaufen
		for (i=0; i<i_Len; i++) {
			chr_Zeichen = strInput.charAt(i);
			switch (chr_Zeichen) {
				case '0':
					str_chrMuster = "101010011";
					break;
				case '1':
					str_chrMuster = "101011001";
					break;
				case '2':
					str_chrMuster = "101001011";
					break;
				case '3':
					str_chrMuster = "110010101";
					break;
				case '4':
					str_chrMuster = "101101001";
					break;
				case '5':
					str_chrMuster = "110101001";
					break;
				case '6':
					str_chrMuster = "100101011";
					break;
				case '7':
					str_chrMuster = "100101101";
					break;
				case '8':
					str_chrMuster = "100110101";
					break;
				case '9':
					str_chrMuster = "110100101";
					break;
			}
			//Code Muster zusammensetzen
			//-> enthaelt der Code Muster String bereits Zeichen?
			if (str_CodeMuster.length()<1) {
				//Ja, CodeMuster mit StartZeichen 'A' initialisieren
				str_CodeMuster = "1011001001";
			} 
			//ZeichenMuster mit einem interChar an das CodeMuster anhaengen
			str_CodeMuster = str_CodeMuster + "0" + str_chrMuster;
		}
		//CodeMuster mit interChar '0' und StopZeichen 'B' abschliessen
		str_CodeMuster = str_CodeMuster + "0" + "1010010011";
		return str_CodeMuster;
	}
	
}
