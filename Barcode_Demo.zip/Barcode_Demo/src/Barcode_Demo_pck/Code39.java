package Barcode_Demo_pck;

public class Code39 {

	public boolean Eingabe_OK (String strInput) {
		
		/*
		 * Eingabge_OK prueft ob der uebergebene String nur 
		 * Zahlen und Großbuchstaben enthaelt. Werden Klein-
		 * buchstaben gefunden werden diese in Grossbuchstaben
		 * gewandelt.
		 */
		
		boolean	b_Ret;
		int 	i=0, i_Len;
		char	chr_Zeichen;
		
		//Laenge der Zeichenkette ermitteln
		i_Len = strInput.length();
		b_Ret = true;
		//Zeichenkette durchlaufen
		for (i=0; i<i_Len; i++) {
			chr_Zeichen = strInput.charAt(i);
			switch (chr_Zeichen) {
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
				case 'A':
				case 'B':
				case 'C':
				case 'D':
				case 'E':
				case 'F':
				case 'G':
				case 'H':
				case 'I':
				case 'J':
				case 'K':
				case 'L':
				case 'M':
				case 'N':
				case 'O':
				case 'P':
				case 'Q':
				case 'R':
				case 'S':
				case 'T':
				case 'U':
				case 'V':
				case 'W':
				case 'X':
				case 'Y':
				case 'Z':	
				b_Ret = true;
				break;
				default:
					return false;
			}
		}
		return b_Ret;
	}
	
	
	public String Strichcode_binaer (String strInput) {
		
		/*
		 * Strichcode_binaer wandelt den nach strInput uebergebenen
		 * String in eine binaeres Strichcodemuster um. Dabei werden 
		 * die einzelnen Zeichen durch ein (interchar space encoded = 0) 
		 * getrennt. 
		 * Die Rueckgabe ist ein binaeres Strichcodemuster als String.
		 */
		
		//Deklarationen
		String	str_CodeMuster="";
		String 	str_chrMuster ="";
		int 	i=0, i_Len;
		char	chr_Zeichen;
		
		//Laenge der Zeichenkette ermitteln
		i_Len = strInput.length();
		//Zeichenkette durchlaufen
		for (i=0; i<i_Len; i++) {
			chr_Zeichen = strInput.charAt(i);
			switch (chr_Zeichen) {
				case '0':
					str_chrMuster = "101001101101";
					break;
				case '1':
					str_chrMuster = "110100101011";
					break;
				case '2':
					str_chrMuster = "101100101011";
					break;
				case '3':
					str_chrMuster = "110110010101";
					break;
				case '4':
					str_chrMuster = "101001101011";
					break;
				case '5':
					str_chrMuster = "110100110101";
					break;
				case '6':
					str_chrMuster = "101100110101";
					break;
				case '7':
					str_chrMuster = "101001011011";
					break;
				case '8':
					str_chrMuster = "110100101101";
					break;
				case '9':
					str_chrMuster = "101100101101";
					break;
				case 'A':
					str_chrMuster = "110101001011";
					break;
				case 'B':
					str_chrMuster = "101101001011";
					break;
				case 'C':
					str_chrMuster = "110110100101";
					break;
				case 'D':
					str_chrMuster = "101011001011";
					break;
				case 'E':
					str_chrMuster = "110101100101";
					break;
				case 'F':
					str_chrMuster = "101101100101";
					break;
				case 'G':
					str_chrMuster = "101010011011";
					break;
				case 'H':
					str_chrMuster = "110101001101";
					break;
				case 'I':
					str_chrMuster = "101101001101";
					break;
				case 'J':
					str_chrMuster = "101011001101";
					break;
				case 'K':
					str_chrMuster = "110101010011";
					break;
				case 'L':
					str_chrMuster = "101101010011";
					break;
				case 'M':
					str_chrMuster = "110110101001";
					break;
				case 'N':
					str_chrMuster = "101011010011";
					break;
				case 'O':
					str_chrMuster = "110101101001";
					break;
				case 'P':
					str_chrMuster = "101101101001";
					break;
				case 'Q':
					str_chrMuster = "101010110011";
					break;
				case 'R':
					str_chrMuster = "110101011001";
					break;
				case 'S':
					str_chrMuster = "101101011001";
					break;
				case 'T':
					str_chrMuster = "101011011001";
					break;
				case 'U':
					str_chrMuster = "110010101011";
					break;
				case 'V':
					str_chrMuster = "100110101011";
					break;
				case 'W':
					str_chrMuster = "110011010101";
					break;
				case 'X':
					str_chrMuster = "100101101011";
					break;
				case 'Y':
					str_chrMuster = "110010110101";
					break;
				case 'Z':
					str_chrMuster = "100110110101";
					break;
			}//SWITCH
			//Code Muster zusammensetzen
			//-> enthaelt der Code Muster String bereits Zeichen?
			if (str_CodeMuster.length()<1) {
				//Ja, CodeMuster mit StartZeichen '*' initialisieren
				str_CodeMuster = "100101101101";
			} 
			//ZeichenMuster mit einem interChar an das CodeMuster anhaengen
			str_CodeMuster = str_CodeMuster + "0" + str_chrMuster;
		}
		//CodeMuster mit interChar '0' und StopZeichen '*' abschliessen
		str_CodeMuster = str_CodeMuster + "0" + "100101101101";
		return str_CodeMuster;
	}
	
	
}
