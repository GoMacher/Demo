/*****************************************
* Ein- und Ausgabefenster des Programmes *
* -------------------------------------- *
* @author Gordana Macher                 *
*****************************************/

package Barcode_Demo_pck;

import java.awt.*;
import java.awt.event.*;

public class GUI_Window extends Frame 
						implements KeyListener, ItemListener {

	//Komponenten
	private static final long serialVersionUID = 1L;
	private Label objInfo1 = new Label();
	private Label objInfo2 = new Label();
	private Label objInfo3 = new Label();
	private TextField objEingabe = new TextField();
	private List objFormatliste = new List(2, false);
	private Button btnClear = new Button();
	private Button btnEnd = new Button();
	private Canvas objAusgabe = new Canvas();
	private TextArea objMeldungen = new TextArea("", 1, 1, TextArea.SCROLLBARS_NONE);
	
	
	//Konstruktor
	public GUI_Window(String strTitle) {
	
		//Frame-Initialisierung
		super(strTitle);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
				System.exit(0);
			}
		});
		
		//Fenster einrichten
		int frameWidth = 440;
		int frameHeight = 500;
		int i=0;
		setSize(frameWidth, frameHeight);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (d.width - getSize().width)/2;
		int y = (d.height - getSize().height)/2;
		setLocation(x, y);
		setBackground(Color.LIGHT_GRAY);
		//leeren Container fuer die Komponenten erstellen
		Panel cp = new Panel(null);
		add(cp);
		//Komponenten -> Eingabeaufforderung
		//Info1:
		objInfo1.setBounds(10, 10, 430, 20);
		objInfo1.setFont(new Font("Verdana", Font.BOLD, 14));
		objInfo1.setText("Bitte den zu interpretierenden Barcode-Wert eingeben");
		cp.add(objInfo1);
		//Info2:
		objInfo2.setBounds(10, 30, 430, 20);
		objInfo2.setFont(new Font("Verdana", Font.BOLD, 14));
		objInfo2.setText("und das Barcode-Format in der Liste auswählen");
		cp.add(objInfo2);
		//Info3:
		objInfo3.setBounds(10, 50, 430, 20);
		objInfo3.setForeground(Color.BLUE);
		objInfo3.setFont(new Font("Verdana", Font.BOLD, 14));
		objInfo3.setText("zulässige Zeichen sind 'A'...'Z' und '0'...'9'");
		cp.add(objInfo3);
		//Komponenten -> Eingabefeld
		objEingabe.setBounds(10, 80, 200, 20);
		objEingabe.setBackground(Color.WHITE);
		objEingabe.setFont(new Font("Verdana", Font.PLAIN, 14));
		objEingabe.setText("");
		objEingabe.addKeyListener(this);
		cp.add(objEingabe);
		//Komponenten -> Auswahl des Barcodeformates
		objFormatliste.setBounds(10, 130, 200, 150);
		objFormatliste.add("Codabar");
		objFormatliste.add("Code39");
		objFormatliste.setMultipleMode(false);
		objFormatliste.addItemListener(this);
		cp.add(objFormatliste);
		//Komponente -> Button der die Eingabefelder loescht
		btnClear.setBounds(225, 300, 200, 30);
		btnClear.setFont(new Font("Verdana", Font.BOLD, 14));
		btnClear.setLabel("Eingabe löschen");
		cp.add(btnClear);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evt) {
				btnClearActionPerformed(evt);
			}
		});
		
		//Komponente -> Button der das Programm beendet
		btnEnd.setBounds(10, 300, 200, 30);
		btnEnd.setFont(new Font("Verdana", Font.BOLD, 14));
		btnEnd.setLabel("beenden");
		cp.add(btnEnd);
		btnEnd.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evt) {
				btnEndActionPerformed(evt);
			}
		});
		
		//Komponente -> Ausgabefeld
		objAusgabe.setBounds(225, 80, 200, 200);
		objAusgabe.setBackground(Color.WHITE);
		cp.add(objAusgabe);
		
		//Komponente -> Meldungen einrichte
		objMeldungen.setBounds(10, 350, 410, 100);
		objMeldungen.setFont(new Font("Verdana", Font.BOLD, 14));
		objMeldungen.setBackground(Color.WHITE);
		objMeldungen.setForeground(Color.BLUE);
		objMeldungen.setEditable(false);
		objMeldungen.setEnabled(false);
		cp.add(objMeldungen);
		
		setResizable(false);
		setVisible(true);
	}
	
	//Ereignisprozeduren
	
	@Override
	public void keyTyped(KeyEvent k_evt) {
	
		//erhaltenen KeyEvent pruefen
		//Zeichen auslesen
		char chr_Key = k_evt.getKeyChar();
		//auf Gueltigkeit pruefen
		//ab Java 12 ist die Abfrage über eine Komma-separierte Liste möglich
		switch (chr_Key) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			break;
			case 'A':
			case 'B':
			case 'C':
			case 'D':
			case 'E':
			case 'F':
			case 'G':
			case 'H':
			case 'I':
			case 'J':
			case 'K':
			case 'L':
			case 'M':
			case 'N':
			case 'O':
			case 'P':
			case 'Q':
			case 'R':
			case 'S':
			case 'T':
			case 'U':
			case 'V':
			case 'W':
			case 'X':
			case 'Y':
			case 'Z':	
				break;
			case 'a':
				k_evt.setKeyChar('A');
				break;
			case 'b':
				k_evt.setKeyChar('B');
				break;
			case 'c':
				k_evt.setKeyChar('C');
				break;
			case 'd':
				k_evt.setKeyChar('D');
				break;
			case 'e':
				k_evt.setKeyChar('E');
				break;
			case 'f':
				k_evt.setKeyChar('F');
				break;
			case 'g':
				k_evt.setKeyChar('G');
				break;
			case 'h':
				k_evt.setKeyChar('H');
				break;
			case 'i':
				k_evt.setKeyChar('I');
				break;
			case 'j':
				k_evt.setKeyChar('J');
				break;
			case 'k':
				k_evt.setKeyChar('K');
				break;
			case 'l':
				k_evt.setKeyChar('L');
				break;
			case 'm':
				k_evt.setKeyChar('M');
				break;
			case 'n':
				k_evt.setKeyChar('N');
				break;
			case 'o':
				k_evt.setKeyChar('O');
				break;
			case 'p':
				k_evt.setKeyChar('P');
				break;
			case 'q':
				k_evt.setKeyChar('Q');
				break;
			case 'r':
				k_evt.setKeyChar('R');
				break;
			case 's':
				k_evt.setKeyChar('S');
				break;
			case 't':
				k_evt.setKeyChar('T');
				break;
			case 'u':
				k_evt.setKeyChar('U');
				break;
			case 'v':
				k_evt.setKeyChar('V');
				break;
			case 'w':
				k_evt.setKeyChar('W');
				break;
			case 'x':
				k_evt.setKeyChar('X');
				break;
			case 'y':
				k_evt.setKeyChar('Y');
				break;
			case 'z':
				k_evt.setKeyChar('Z');
				break;
			default:
			  //Merker fuer ungueltiges Zeichen setzten
				k_evt.setKeyChar(' ');
			}//SWITCH
	}
	
	@Override
	public void keyPressed(KeyEvent arg0) {
	
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
			String str_Text = objEingabe.getText();
			
			for (int i=0; i<str_Text.length(); i++) {
			if (str_Text.charAt(i) == ' ') {
				//wenn Merker = " " dann diesen loeschen
				//den String-Teil vor dem Merker kopieren
				str_Text = "";
				for (int j=0; j<i; j++) {
					str_Text = str_Text + objEingabe.getText().charAt(j);
				}
				//den String-Teil nach dem Merker kopieren
				for (int k=(i+1); k<objEingabe.getText().length(); k++) {
					str_Text = str_Text + objEingabe.getText().charAt(k);
				}
				System.out.println("String: " + str_Text);
				objEingabe.setText(str_Text);
			}
		}
		
		//Textlaenge pruefen
		if (str_Text.length()>10) {
			//Fehlermeldung -> String zu lang
			objMeldungen.setText("F E H L E R M E L D U N G:\n\n Der von Ihnen Eingegebene Barcode is zu lang. \n\n letztes Zeichen wird gelöscht!\n");
			//Ueberschuessige Zeichen loeschen
			objEingabe.setText(str_Text.substring(0, str_Text.length()-1));
		}
	}
	
	@Override
	public void itemStateChanged(ItemEvent itm_evt) {
		
		//Deklarationen
		boolean b_allesOK;
		String str_CodeWert = "";
		String str_Format = "";
		String str_Muster = "";
		
		//ist das Eingabefeld nicht leer?
		if (objEingabe.getText().length()>0){
			//-> JA, es ist eine Eingabe vorhanden
			//Eingabefenster sperren
			Komponenten_sperren();
			//Eingabe auslesen
			str_CodeWert = objEingabe.getText();
			//Code Format auslesen
			str_Format = objFormatliste.getSelectedItem();
			//wurde ein Element der Liste ausgewaehlt?
			switch (objFormatliste.getSelectedIndex()) {
				case 0: //Codabar -> rein nummerischer Code
					//pruefen ob die Eingabe Buchstaben enthaelt
					//Format Objekt = Codabar erzeugen
					Codabar myCode_0 = new Codabar();
					//Eingegebenen String auf ungueltige Zeichen pruefen
					b_allesOK = myCode_0.Eingabe_OK(str_CodeWert);
					//Rueckgabewert pruefen
					if (b_allesOK == true) {
						//und in das Barcodemuster wandeln
						str_Muster = myCode_0.Strichcode_binaer(str_CodeWert);
					}
					break;
				case 1: //Code39 -> alpha-nummerischer Code
					//Meldungsfenster loeschen
					objMeldungen.setText("");
					//Format Objekt = Code 39 erzeugen
					Code39 myCode_1 = new Code39();
					//und in das Barcodemuster wandeln
					str_Muster = myCode_1.Strichcode_binaer(str_CodeWert);
					break;
			} //SWITCH
			if (str_Muster.length()>0) {
				//Barcode Objekt erzeugen
				//-> ermitteln welches Item ausgewaehlt wurde
				Barcode aktCode = new Barcode(str_CodeWert, str_Format, str_Muster);
				//Barcode zeichnen 
				Barcode_zeichnen(aktCode.getCodeMuster());
			} else {
				if (str_Format.contentEquals("Codabar")==true) {
					//Fehlermeldung ausgeben -> ungueltige Zeichen
					objMeldungen.setText("F E H L E R M E L D U N G:\n\n CODABAR ist ein nummerischer Bardoce.\n\n Bitte die Buchstaben löschen!\n");
				} else {
					//Fehlermeldung ausgeben, das beim Erstellen des Barcodes ein Fehler aufgetreten ist
					objMeldungen.setText("F E H L E R M E L D U N G:\n\n Beim Erstellen des Barcodes ist ein Fehler aufgetreten.\n\n Bitte erneut versuchen!\n");
				}
			}
			//Eingabefenster entsperren
			Komponenten_entsperren();
		} else {
			//Auswahl aufheben
			Eingabefelder_loeschen();
		}
	}

	public void btnClearActionPerformed(ActionEvent evt) {
		Eingabefelder_loeschen();
	}
	
	public void btnEndActionPerformed(ActionEvent evt) {
		System.exit(0);
	}
	
	public void Eingabefelder_loeschen() {
		
		int i;
		
		//Eingabefelder loeschen und aktualisieren
		objEingabe.setText("");
		objEingabe.repaint();
		//Auswahl ruecksetzen
		//-> ausgewaehltes Element ermitteln und ruecksetzten
		i = objFormatliste.getSelectedIndex();
		objFormatliste.deselect(i);
		//Ausgabebereich ruecksetezn
		Ausgabefeld_loeschen();
		//Meldungsfenster loeschen
		objMeldungen.setText ("");
	}
	
	public void Ausgabefeld_loeschen() {
		objAusgabe.setBounds(225, 80, 225, 80);
		objAusgabe.setBounds(225, 80, 200, 200);
	}
	
	void Komponenten_sperren() {
		objEingabe.setEnabled(false);
		objFormatliste.setEnabled(false);
		btnClear.setEnabled(false);
		btnEnd.setEnabled(false);	
	}
	
	void Komponenten_entsperren() {
		objEingabe.setEnabled(true);
		objFormatliste.setEnabled(true);
		btnClear.setEnabled(true);
		btnEnd.setEnabled(true);	
	}
	
	public void Barcode_zeichnen (String strMuster) {
		
		//Startwert berechnen
		int x = (200 - strMuster.length())/2;
		int y = (200 - 160) / 2;
		
		
		//Schleife durchlaufen wie Codezahlen vorhanden sind
		for (int i=0; i<strMuster.length(); i++) {
			//ist das ausgelesene Zeichen eine '1'?
			if (strMuster.charAt(i) == '1') {
				Graphics g = objAusgabe.getGraphics();
				g.setColor(Color.BLACK);
				g.drawLine((x+i), y, x+i, y+160);
				objAusgabe.setBounds(225, 80, 200, 200);
			} else {
				//wenn nein, dann weisse Linie, entspricht nichts
				Graphics g = objAusgabe.getGraphics();
				g.setColor(Color.RED);
				g.drawLine(x+1, y, x+1, y+160);
				objAusgabe.setBounds(225, 80, 200, 200);
			}
		}
	} 

	//MAIN
	public static void main(String[] args) {
		
		new GUI_Window("Barcode-Tool");
		
	}

}
