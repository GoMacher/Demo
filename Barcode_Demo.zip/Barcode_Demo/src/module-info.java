module Barcode_Demo {
	
	requires java.desktop;
	requires java.datatransfer;
	
}